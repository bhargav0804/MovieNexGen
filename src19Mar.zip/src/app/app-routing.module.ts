import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login/login.component';
import { RegisterComponent } from './login/register/register.component';
import { HomeComponent } from './user/home/home.component';
import { MovieCardGridComponent } from './user/movie-card-grid/movie-card-grid.component';
import { MovieDetailsComponent } from './user/movie-details/movie-details.component';
import { ProfileComponent } from './user/profile/profile.component';

const routes: Routes = [
  {path: '', redirectTo:'/login',pathMatch:'full'},
  {path: 'login',component:LoginComponent},
  {path: 'register',component:RegisterComponent},
  {path: 'user',component:HomeComponent},
  {path: 'movie-details',component:MovieDetailsComponent},
  {path: 'profile',component:ProfileComponent},
  {path: 'movieGrid',component: MovieCardGridComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{scrollPositionRestoration:'enabled'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
