import { Component, OnInit, Output } from '@angular/core';
import { APIService } from 'src/app/api.service';
declare var $: any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  MyList:string = "MyList";
  Trending:string = "Trending";
  RecentlyAdded:string = "RecentlyAdded";
   movies=[];
  constructor(private apiService:APIService){}
ngOnInit(){
  this.apiService.getAllMovies().subscribe(result=>{
    console.log(result);
    this.movies=result;
  });
}

getMovies(){
 
 
}
  
}
