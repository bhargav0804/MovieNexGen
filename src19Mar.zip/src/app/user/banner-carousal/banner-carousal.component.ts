import { Component, OnInit } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-banner-carousal',
  templateUrl: './banner-carousal.component.html',
  styleUrls: ['./banner-carousal.component.scss']
})
export class BannerCarousalComponent implements OnInit {
  cards = [
    {
      title: 'Card Title 1',
      description: 'This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.',
      buttonText: 'Button',
      imgSrc: '../../../assets/background-final.jpg'
    },
    {
      title: 'Card Title 2',
      description: 'This card has supporting text below as a natural lead-in to additional content.',
      buttonText: 'Button',
      imgSrc: '../../../assets/background-final.jpg'
    },
    {
      title: 'Card Title 3',
      description: 'This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action. This text is much longer so that you can see a significant difference between the text in  previous tabs.',
      buttonText: 'Button',
      imgSrc: '../../../assets/background-final.jpg'
    },
    {
      title: 'Card Title 4',
      description: 'Some quick example text to build on the card title and make up the bulk of the card content',
      buttonText: 'Button',
      imgSrc: '../../../assets/background-final.jpg'
    },
    {
      title: 'Card Title 5',
      description: 'Some quick example text to build on the card title and make up the bulk of the card content',
      buttonText: 'Button',
      imgSrc: '../../../assets/background-final.jpg'
    },
    {
      title: 'Card Title 6',
      description: 'Some quick example text to build on the card title and make up the bulk of the card content',
      buttonText: 'Button',
      imgSrc: '../../../assets/background-final.jpg'
    }
  ];
  constructor() { }

  ngOnInit(): void {
    $('#carouselExampleControls').carousel({
      interval: 1500,
    });
  }

}
