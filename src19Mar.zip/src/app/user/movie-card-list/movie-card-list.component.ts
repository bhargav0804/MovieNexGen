import {
  Component,
  HostListener,
  Input,
  OnInit,
} from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { APIService } from 'src/app/api.service';

declare var $: any;

@Component({
  selector: 'app-movie-card-list',
  templateUrl: './movie-card-list.component.html',
  styleUrls: ['./movie-card-list.component.scss'],
})
export class MovieCardListComponent implements OnInit {
  @Input() id: string;

  // cards = [
  //   {
  //     title: 'Card Title 1',
  //     description:
  //       'Some quick example text to build on the card title and make up the bulk of the card content',
  //     buttonText: 'Button',
  //     img:
  //       'https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(35).jpg',
  //   },
  //   {
  //     title: 'Card Title 2',
  //     description:
  //       'Some quick example text to build on the card title and make up the bulk of the card content',
  //     buttonText: 'Button',
  //     img:
  //       'https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg',
  //   },
  //   {
  //     title: 'Card Title 3',
  //     description:
  //       'Some quick example text to build on the card title and make up the bulk of the card content',
  //     buttonText: 'Button',
  //     img:
  //       'https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg',
  //   },
  //   {
  //     title: 'Card Title 4',
  //     description:
  //       'Some quick example text to build on the card title and make up the bulk of the card content',
  //     buttonText: 'Button',
  //     img:
  //       'https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg',
  //   },
  //   {
  //     title: 'Card Title 5',
  //     description:
  //       'Some quick example text to build on the card title and make up the bulk of the card content',
  //     buttonText: 'Button',
  //     img:
  //       'https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg',
  //   },
  //   {
  //     title: 'Card Title 6',
  //     description:
  //       'Some quick example text to build on the card title and make up the bulk of the card content',
  //     buttonText: 'Button',
  //     img:
  //       'https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg',
  //   },
  //   {
  //     title: 'Card Title 7',
  //     description:
  //       'Some quick example text to build on the card title and make up the bulk of the card content',
  //     buttonText: 'Button',
  //     img:
  //       'https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg',
  //   },
  //   {
  //     title: 'Card Title 8',
  //     description:
  //       'Some quick example text to build on the card title and make up the bulk of the card content',
  //     buttonText: 'Button',
  //     img:
  //       'https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg',
  //   },
  //   {
  //     title: 'Card Title 9',
  //     description:
  //       'Some quick example text to build on the card title and make up the bulk of the card content',
  //     buttonText: 'Button',
  //     img:
  //       'https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg',
  //   },
  // ];
  @Input() cards=[];
  slides: any = [[]];
  columnlength: string = 'col-3';

  chunk(arr, chunkSize) {
    let R = [];
    for (let i = 0, len = arr.length; i < len; i += chunkSize) {
      R.push(arr.slice(i, i + chunkSize));
    }
    return R;
  }
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.setSlide(event.target.innerWidth);

  }
  setSlide(myWidth:number){
    console.log();
    
    if (myWidth <= 576) {
      this.columnlength = 'col-12';
      this.slides = this.chunk(this.cards, 1);
    } else if (myWidth <= 768) {
      this.columnlength = 'col-6';
      this.slides = this.chunk(this.cards, 2);
    } else if (myWidth <= 1200) {
      this.columnlength = 'col-4';
      this.slides = this.chunk(this.cards, 3);
    } else {
      this.columnlength = 'col-3';
      this.slides = this.chunk(this.cards, 4);
    }
   
  }
  constructor(private apiService:APIService , private route:Router) {}
  ngOnInit() {
    //this.slides = this.chunk(this.cards, 4);
    this.setSlide(window.innerWidth);
  
  }
  GoToGrid(){
    this.route.navigate(['movieGrid']);
  }
 
}

//}
