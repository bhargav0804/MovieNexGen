import { Component, HostListener, OnInit } from '@angular/core';

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.scss']
})
export class MovieDetailsComponent implements OnInit {
 
  windowWidth:number;
  constructor() { }

  ngOnInit(): void {
    this.windowWidth=window.innerWidth;

  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.windowWidth=event.target.innerWidth;
  }
}
