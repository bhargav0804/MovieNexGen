import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-movie-card',
  templateUrl: './movie-card.component.html',
  styleUrls: ['./movie-card.component.scss']
})
export class MovieCardComponent implements OnInit {

@Input() movieDetails:any;

  constructor(private route: Router) { }

  ngOnInit(): void {
  }
  cardClick(){
    this.route.navigate(['movie-details'])
  }
}
