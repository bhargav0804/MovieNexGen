import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class APIService {
  baseUrl = 'http://localhost:56128/api/';
  constructor(private http: HttpClient) {}
  allMovies: Array<any> = [];
  allMoviesObs: BehaviorSubject<any> = new BehaviorSubject<any>(this.allMovies);

  movieDetail: any = undefined;
  movieDetailObs: BehaviorSubject<any> = new BehaviorSubject<any>(this.movieDetail);

  genresMovies: any= [];
  genresMoviesObs: BehaviorSubject<any> = new BehaviorSubject<any>(this.genresMovies);

  watchLater: any = [];
  watchLaterObs: BehaviorSubject<any> = new BehaviorSubject<any>(this.watchLater);

  allReviews: any = undefined;
  allReviewsObs: BehaviorSubject<any> = new BehaviorSubject<any>(this.allReviews);

  reviewOfUser: any = [];
  reviewOfUserObs: BehaviorSubject<any> = new BehaviorSubject<any>(this.reviewOfUser);

  mainContentFlag:boolean = true;
  mainContentFlagObs:BehaviorSubject<any> = new BehaviorSubject(this.mainContentFlag); 
  
  searchContent:string = "";
  searchContentObs:BehaviorSubject<any> = new BehaviorSubject(this.searchContent); 

  public getMovies(): Observable<any> {
    if (this.allMovies.length==0) {
      this.updateAllMoviesLocally();
    }
    return this.allMoviesObs.asObservable();
  }

  updateAllMoviesLocally() {
    this.getAllMovies().subscribe((data) => {
      console.log("in update",data);
      
      if (data != undefined || data != null) {
        this.allMovies = data;
        this.allMoviesObs.next(this.allMovies);
      }
    });
  }
  
  getMovieById(movieId: number): Observable<any> {
    if (this.allMovies != undefined) {
      //console.log('in');
      
      let movie = this.allMovies.find((movie) =>  movie.MovieId == movieId);
      if (movie != undefined) {
        this.movieDetail = movie;
        this.movieDetailObs.next(this.movieDetail);
      } else {
        this.getMovie(movieId).subscribe({
          next: (data) => {
            if (data != undefined || data != null) {
              this.movieDetail = data;
              this.movieDetailObs.next(this.movieDetail);
            }
          },
        });
      }
    } else {
      this.getMovie(movieId).subscribe({
        next: (data) => {
          if (data != undefined || data != null) {
            this.movieDetail = data;
            this.movieDetailObs.next(this.movieDetail);
          }
        },
      });
    }
    return this.movieDetailObs.asObservable();
  }

 
  getGenreMovies(genreName: string) {    
    
    if(this.genresMovies.find((item)=>item.name==genreName)==undefined){  
      this.updateGenreMoviesLocally(genreName);
    }
    return this.genresMoviesObs.asObservable();
  }

  updateGenreMoviesLocally(genreName:string){    
    
    this.getMovieByGenre(genreName).subscribe({
      next: (data) => {
        if (data != undefined) {
          this.genresMovies.push({ name: genreName, data: data });
          this.genresMoviesObs.next(this.genresMovies);
        }
      },
    });
  }

  public getWatchLaterMovies(userId:number): Observable<any> {
    if (this.watchLater.length==0) {
      this.updateWatchLaterMoviesLocally(userId);
    }
    return this.watchLaterObs.asObservable();
  }

  updateWatchLaterMoviesLocally(userId:number){
    this.getWatchLaterMoviesByUserId(userId).subscribe((data) => {
      console.log("in update",data);
      
      if (data != undefined || data != null) {
        this.watchLater = data;
        this.watchLaterObs.next(this.watchLater);
      }
    });
  }

  public getReviewsOfUser(userId:number): Observable<any> {
    if (this.reviewOfUser.length==0) {
      this.updateReviewsOfUserLocally(userId);
    }
    return this.reviewOfUserObs.asObservable();
  }

  updateReviewsOfUserLocally(userId:number){
    this.getReviewsOfUserById(userId).subscribe((data) => {
      console.log("in update",data);
      
      if (data != undefined || data != null) {
        this.reviewOfUser = data;
        this.reviewOfUserObs.next(this.reviewOfUser);
      }
    });
  }

  public getAllMovies(): Observable<any> {
    return this.http.get(this.baseUrl + 'user/movies');
  }
  public getMovie(movieId: number): Observable<any> {
    return this.http.get(this.baseUrl + 'movie/movie?id=' + movieId);
  }
  public getReviews(movieId: number): Observable<any>{
    return this.http.get(this.baseUrl + "movie/review?id=" + movieId);
  }

  public getMovieByGenre(genreName:string):Observable<any>{
    return this.http.get(this.baseUrl+'movie/movie?genrename='+genreName);
  }

  public getWatchLaterMoviesByUserId(id:number):Observable<any>{
    return this.http.get(this.baseUrl + '/user/watchlater?id='+id);
  }
  public getReviewsOfUserById(id:number):Observable<any>{
    return this.http.get(this.baseUrl + 'user/review?id='+id);
  }

  public getWatchHistoryByUserId(id:number):Observable<any>{
    return this.http.get(this.baseUrl + '/user/history?id='+id);
  }

  getMainContentFlag():Observable<any>{
    return this.mainContentFlagObs.asObservable();
  }

  getSearchContent():Observable<any>{
    return this.searchContentObs.asObservable();
  }

}
