import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { SessionService } from 'src/app/user/session.service';
import { LoginApiService } from '../services/login-api.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  //, [Validators.email, Validators.required ]
  //, [Validators.required, Validators.min(3) ]
  loginFormData: any = {};
  constructor(
    private route: Router,
    private router: ActivatedRoute,
    private _loginService: LoginApiService,
    private sessionService: SessionService
  ) {}
  loginForm: FormGroup = new FormGroup({
    email: new FormControl(''),
    password: new FormControl(''),
  });
  hide = true;
  get email() {
    return this.loginForm.get('email');
  }
  get password() {
    return this.loginForm.get('password');
  }
  ngOnInit(): void {
    this.loginForm = new FormGroup({
      email: new FormControl('', [
        Validators.email,
        Validators.required,
        Validators.pattern(
          '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$'
        ),
      ]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(8),
        Validators.maxLength(15),
        Validators.pattern(
          '(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[$@$!#^~%*?&,.<>"\'\\;:{\\}\\[\\]\\|\\+\\-\\=\\_\\)\\(\\)\\`\\/\\\\\\]])[A-Za-z0-9d$@].{7,}'
        ),
      ]),
    });
  }
  gotoRegister() {
    this.route.navigate(['register']);
  }
  logIn() {
    this.loginFormData['email'] = this.loginForm.get('email').value;
    this.loginFormData['password'] = this.loginForm.get('password').value;

    this._loginService.loginUser(this.loginFormData).subscribe({
      next: (data) => {
        console.log(data);
        if (data.token == null) {
          if(data.user == null){
            console.log('User not exist');
          }else{
            console.log('User is blocked..')
          }
          
        }else{
          console.log('Login');
          this.sessionService.setLocalSession(data.token, data.user);
          this.route.navigate(['user']);
        }
      },
    });
  }
}
