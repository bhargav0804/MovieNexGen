import { Component, OnInit, Output } from '@angular/core';
import { APIService } from 'src/app/api.service';
import { SearchService } from '../search.service';
declare var $: any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  MyList: string = 'MyList';
  Trending: string = 'Trending';
  RecentlyAdded: string = 'RecentlyAdded';
  Action: string = 'Action';
  actionData: any;
  AllMovies: string = 'AllMovies';
  Comedy: string = 'Comedy';
  MyListData = [];
  //  ActionData=[];
  //  ComedyData=[];
  AllMoviesData = [];
  genresMovies = [];
  userId:number;
  mainContentFlag:boolean;
  constructor(private _apiService: APIService) {}
  ngOnInit() {
    this._apiService.getMainContentFlag().subscribe((data)=>{
      console.log("New Log",data);
      
      if(data != null || data != undefined){        
        this.mainContentFlag = data;
      }
    })
    // this.mainContentFlag = this._searchService.mainContentFlag;
    this.getGenreMovies('Action');
    this.getGenreMovies('Thriller');
    this.getGenreMovies('Horror');
    this.getGenreMovies('Comedy');

    this._apiService.getMovies().subscribe({
      next: (result) => {
        console.log(result);

        this.AllMoviesData = result;
      },
    });
    this.userId = parseInt(localStorage.getItem('UserId'));

    this._apiService.getWatchLaterMovies(this.userId).subscribe({
      next:(result)=>{
        this.MyListData = result;
      }
    })
  }

  getGenreMovies(genre: string) {
    this._apiService.getGenreMovies(genre).subscribe((data) => {
      this.genresMovies = data;
    });
  }
}
