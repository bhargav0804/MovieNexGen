import { Component, HostListener, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { APIService } from 'src/app/api.service';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {
  windowWidth: number;
  username: string;
  userId: number;
  reviews: any = undefined;
  movieData: any = undefined;
  mainContentFlag:boolean;
  constructor(private _apiService: APIService) {}
  srcProfile:any;
  nameFormControl = new FormControl('', [
    Validators.required,
    Validators.minLength(3),
    Validators.pattern('[a-zA-Z ]*')
  ]);
  mobileFormControl =  new FormControl('', [
    Validators.required,
    Validators.maxLength(10),
    Validators.pattern('[6-9]\\d{9}'),
  ]);
  ngOnInit(): void {
    this._apiService.getMainContentFlag().subscribe((data)=>{      
      if(data != null || data != undefined){        
        this.mainContentFlag = data;
      }
    })
    this.windowWidth = window.innerWidth;

    this.userId = parseInt(localStorage.getItem('UserId'));
    this._apiService.getReviewsOfUser(this.userId).subscribe({
      next: (result) => {
        if (result != undefined) {
          this.reviews = result;
          console.log(this.reviews);
        }
      },
    });

    this._apiService.getWatchHistoryByUserId(this.userId).subscribe({
      next:(data)=>{
        if (data != undefined) {
          this.movieData = data;
          
        }
      }
    })


    // this.username = localStorage.getItem('user')['']
  }
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.windowWidth = event.target.innerWidth;
  }

  uploadProfilePic(event){
//     var f=document.createElement('input');
//     f.id="uploadId"
//     f.style.display='none';
//     f.type='file';
//     f.name='file';
//     // f.change="fileOnChange($event)";
//     f.accept="image/x-png,image/jpeg"
//     document.getElementById('uploadProfile').appendChild(f);
//     f.click();

//     var file=document.getElementById('uploadId');
// console.log(file);
    console.log(event.target.files[0]);
    // this.srcProfile=event.target.files[0]
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
          this.srcProfile = event.target.result;
          console.log("srcProfile",this.srcProfile)
      }
      reader.readAsDataURL(event.target.files[0]);
  }
   
  
  }
  fileOnChange(){

  }
}
