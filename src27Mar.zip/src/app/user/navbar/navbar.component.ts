import { Container } from '@angular/compiler/src/i18n/i18n_ast';
import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { APIService } from 'src/app/api.service';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  selected = 'option2';
  collapsed = true;
  windowWidth:number;
  searchContent:string = '';
  constructor(private route: Router, private _apiService: APIService) { }

  ngOnInit(): void {
    this.windowWidth=window.innerWidth;
  }
  GotoProfile(){
    this.route.navigate(['profile'])
  }
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.windowWidth=event.target.innerWidth;
  }
  logout(){
    localStorage.clear();
    this.route.navigate(['login'])
  }

  isInMovieDetails(){
    if(this.route.url.includes('/movie-details')){
      return true;
    }
    return false;
  }
  Search(event:Event){   
    if(this.searchContent.length != 0){
      this._apiService.mainContentFlag = false;
      this._apiService.mainContentFlagObs.next(false);
      this._apiService.searchContent = this.searchContent;
      this._apiService.searchContentObs.next(this.searchContent);
      // this.route.navigate(['movieGrid',this.searchContent]);
    } else{    
      this._apiService.mainContentFlag = true;
      this._apiService.mainContentFlagObs.next(true);
      // window.history.back();
    }
  }
}

