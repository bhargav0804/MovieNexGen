import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatTabChangeEvent } from '@angular/material/tabs';
import {  ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { APIService } from 'src/app/api.service';
import { SearchService } from '../search.service';

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.scss']
})
export class MovieDetailsComponent implements OnInit,OnDestroy {
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
  movieDetails:any;
  reviews:any = undefined;
  windowWidth:number;
  mainContentFlag:boolean;
id:any
  movieObs:Subscription;
  constructor(private _apiService:APIService,private activatedRoute:ActivatedRoute,private route:Router) { }
   
  
  ngOnInit(): void {
    // this.activatedRoute.params.subscribe({
    //   next:(data)=>{
    //     this.id=data['id'];
        
    //   }
    // })

    
    this._apiService.searchContentObs.next('');
    this._apiService.mainContentFlagObs.next(true);
    
    this._apiService.getMainContentFlag().subscribe((data)=>{    
      if(data != null || data != undefined){        
        this.mainContentFlag = data;
      }
    })
    this.windowWidth=window.innerWidth;
    this.movieDetails = {Genres:'' };
        this.movieObs=this._apiService.getMovieById(this.activatedRoute.snapshot.params.id).subscribe({
          next:(result)=>{
            if(result!=undefined)
            {
              this.movieDetails=result;
             
              console.log(this.movieDetails);
              
            }
          }
        });

  }
 
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.windowWidth=event.target.innerWidth;
  }
  ngOnDestroy(){
    this.movieObs.unsubscribe();
  }

  tabClick(event: MatTabChangeEvent) {
    const tab = event.tab.textLabel;
    console.log(tab);
    if(tab == 'Reviews'){
      console.log(this.activatedRoute.snapshot.params.id);
      if(this.reviews==undefined){
        this._apiService.getReviews(this.activatedRoute.snapshot.params.id).subscribe({
          next:(result)=>{
            if(result!=undefined)
            {
              this.reviews=result;
              console.log(this.reviews);
              
            }
          }
        })
      }
      
    }
  }

  shareBtnClk(event:any){
    this.http.get("http://localhost:56128/api/user/share?email="+" ");
  }
}
