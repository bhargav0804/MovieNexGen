import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { LoginComponent } from './login/login/login.component';
import { RegisterComponent } from './login/register/register.component';
import { HomeComponent } from './user/home/home.component';
import { MovieCardGridComponent } from './user/movie-card-grid/movie-card-grid.component';
import { MovieDetailsComponent } from './user/movie-details/movie-details.component';
import { ProfileComponent } from './user/profile/profile.component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  // { path: 'login', component: LoginComponent , canActivate:[AuthGuard],data: {
  //   expectedRoles: ['']}},
  // { path: 'register', component: RegisterComponent,canActivate:[AuthGuard],data: {
  //   expectedRoles: ['']} },
  { path: 'login', component: LoginComponent},
  { path: 'register', component: RegisterComponent},
  { path: 'user', component: HomeComponent, canActivate: [AuthGuard], data: {
    expectedRoles: ['User']}},
  { path: 'movie-details/:id', component: MovieDetailsComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'movieGrid/:type', component: MovieCardGridComponent },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
